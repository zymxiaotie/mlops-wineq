from setuptools import setup, find_packages # packages in src

setup(
    name="src",
    version="0.0.0",
    description="it is a wine Q package",
    author="zymxiaotie",
    packages=find_packages(),
    license="MIT"
)